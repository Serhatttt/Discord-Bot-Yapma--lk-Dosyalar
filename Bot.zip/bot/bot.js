const Discord = require('discord.js');
const client = new Discord.Client();

client.on('ready', () => {
  console.log(`Ba�land�m! Ben; ${client.user.tag}!`); // Konsolda G�steren Yaz�d�r.
});

client.on('message', msg => {
  if (msg.content === 'ping') {
    msg.reply('Pong!');
  }
});

client.login('token'); // Token Yazan Yere Botun Giri� Kimli�i(Token) Yaz�yoruz.